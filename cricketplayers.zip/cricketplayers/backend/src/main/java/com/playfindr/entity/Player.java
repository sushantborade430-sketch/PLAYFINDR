package com.playfindr.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "players")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Player {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false, length = 64)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "city_id", nullable = false)
    private City city;

    @Column(length = 100)
    private String locality;

    @Column(precision = 9, scale = 6)
    private Double latitude;

    @Column(precision = 9, scale = 6)
    private Double longitude;

    @Lob
    @Column(name = "roles_json", columnDefinition = "json")
    private String rolesJson;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private SkillLevel skillLevel;

    @Lob
    @Column(name = "availability_json", columnDefinition = "json")
    private String availabilityJson;

    @Column(length = 500)
    private String bio;

    @Column(length = 20)
    private String phone;

    @Column(length = 255)
    private String profileImageUrl;

    private Boolean verified = false;

    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt;

    public enum SkillLevel {
        Beginner, Intermediate, Professional
    }
}
