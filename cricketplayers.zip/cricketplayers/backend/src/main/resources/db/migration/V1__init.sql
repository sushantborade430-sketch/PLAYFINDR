-- Users table
CREATE TABLE users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('PLAYER','ADMIN') DEFAULT 'PLAYER',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_active TINYINT(1) DEFAULT 1
);

-- Cities table
CREATE TABLE cities (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(64) NOT NULL,
  state VARCHAR(64) NOT NULL,
  country VARCHAR(64) NOT NULL
);

INSERT INTO cities (name, state, country) VALUES
  ('Mumbai', 'Maharashtra', 'India'),
  ('Delhi', 'Delhi', 'India'),
  ('Bengaluru', 'Karnataka', 'India'),
  ('Chennai', 'Tamil Nadu', 'India'),
  ('Hyderabad', 'Telangana', 'India');

-- Players table
CREATE TABLE players (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  name VARCHAR(64) NOT NULL,
  city_id BIGINT NOT NULL,
  locality VARCHAR(100),
  latitude DECIMAL(9,6),
  longitude DECIMAL(9,6),
  roles_json JSON,
  skill_level ENUM('Beginner', 'Intermediate', 'Professional'),
  availability_json JSON,
  bio VARCHAR(500),
  phone VARCHAR(20),
  profile_image_url VARCHAR(255),
  verified TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (city_id) REFERENCES cities(id)
);

CREATE INDEX idx_city_id ON players(city_id);
CREATE INDEX idx_lat_lng ON players(latitude, longitude);
CREATE INDEX idx_roles ON players(roles_json);
CREATE INDEX idx_skill_level ON players(skill_level);
