# PlayFindr Backend

A Spring Boot REST API to power city-wise cricket player matchmaking for PlayFindr.

## Getting Started

### Prerequisites
- Java 17
- Maven
- MySQL

### Setup
1. Clone the repository:
   ```bash
   git clone <repo-url>
   cd backend
   ```
2. Configure your MySQL credentials and AWS S3 keys in `src/main/resources/application.properties`.
3. Ensure MySQL is running and a database `playfindr` exists.
4. Build & run:
   ```bash
   mvn spring-boot:run
   ```

### With Docker
Build backend container:
```bash
docker build -t playfindr-backend .
```
Run (make sure MySQL is up, ideally using docker-compose):
```bash
docker run --env-file .env -p 8080:8080 playfindr-backend
```

### Endpoints
- `POST /api/auth/register` – register user
- `POST /api/auth/login` – login, get JWT
- `POST /api/auth/refresh` – refresh JWT

See further API documentation in the main repo.
